/**
 * 
 */
/**
 * 
 */
module GuiIntegrateion {
	requires java.desktop;
}